import UIKit

var favouriteNumber:Int = 15
var name:String = "abdulrahman"
var hobby = "fencing"

print("Hello my name is \(name) and my favourite nummber is \(favouriteNumber) and my hobby is \(hobby) \n and i was born in the year \(BirthOfDate) ")

let BirthOfDate = 2008
